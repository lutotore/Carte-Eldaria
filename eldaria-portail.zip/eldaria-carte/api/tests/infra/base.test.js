import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { MIGRATIONS, ouvrirBase } from '../../src/infra/base.js'

const tables = (db) => db.prepare("SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name").all().map((t) => t.name)

describe('base de données', () => {
  let dossier
  afterEach(() => dossier && rmSync(dossier, { recursive: true, force: true }))

  it('crée le schéma à la première ouverture', () => {
    const db = ouvrirBase(':memory:')
    expect(tables(db)).toEqual(expect.arrayContaining([
      'campagnes', 'etats_campagne', 'invitations', 'participations', 'reinitialisations', 'sessions', 'utilisateurs',
    ]))
    expect(db.prepare('PRAGMA user_version').get().user_version).toBe(MIGRATIONS.length)
  })

  it('applique les clés étrangères', () => {
    const db = ouvrirBase(':memory:')
    expect(() => db.prepare("INSERT INTO participations (utilisateur_id, campagne_id, role, rejoint_le) VALUES (99, 99, 'joueur', 'd')").run()).toThrow()
  })

  it('ne rejoue pas les migrations déjà appliquées', () => {
    dossier = mkdtempSync(join(tmpdir(), 'eldaria-'))
    const chemin = join(dossier, 'test.db')
    const premiere = ouvrirBase(chemin)
    premiere.prepare("INSERT INTO campagnes (nom, cree_le) VALUES ('Eldaria', '2026-10-01')").run()
    premiere.close()
    const seconde = ouvrirBase(chemin)
    expect(seconde.prepare('SELECT nom FROM campagnes').all()).toHaveLength(1)
    seconde.close()
  })

  it('refuse un rôle inconnu', () => {
    const db = ouvrirBase(':memory:')
    db.prepare("INSERT INTO utilisateurs (identifiant, empreinte_mdp, cree_le) VALUES ('tom', 'x', 'd')").run()
    db.prepare("INSERT INTO campagnes (nom, cree_le) VALUES ('Eldaria', 'd')").run()
    expect(() => db.prepare("INSERT INTO participations (utilisateur_id, campagne_id, role, rejoint_le) VALUES (1, 1, 'roi', 'd')").run()).toThrow()
  })

  it('traite les identifiants sans tenir compte de la casse', () => {
    const db = ouvrirBase(':memory:')
    db.prepare("INSERT INTO utilisateurs (identifiant, empreinte_mdp, cree_le) VALUES ('Tom', 'x', 'd')").run()
    expect(() => db.prepare("INSERT INTO utilisateurs (identifiant, empreinte_mdp, cree_le) VALUES ('tom', 'x', 'd')").run()).toThrow(/UNIQUE/)
  })
})
